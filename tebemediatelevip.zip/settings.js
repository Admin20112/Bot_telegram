/*
• Base Ori Dilzz Official
Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Bikinan Sendiri, Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Dilzz [ Develover Sc ]  
- Dilzz [ Support ]
- Dilzz [Recode]
- Pengguna Bot Yang Selalu Support

• Recode By ( Dilzz  )
*/

const settings = {
  token: '7736141160:AAEdkfq2TcU6fsNABA8nurGEewLYy_OUGOQ', // Token Bot
  adminId: '7736141160',
  urladmin: 'https://t.me/savedilz',
  domain: 'https://marketplaceshoprenzzprivate.zanofc.biz.id', // Isi dengan domain yang digunakan
  plta: 'ptla_sJYKjW3WYKA7sHpIv58idVTaaBqaSrwYYtiUGI8lbgm', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc_Lkpq6Vo4u1jdzJXG7UhtiqxPDMRS6iDiI04GSGpsUpK', // Isi dengan nilai pltc yang sesuai
  pp: 'https://i.top4top.io/p_32003qqrw1.jpg',
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;