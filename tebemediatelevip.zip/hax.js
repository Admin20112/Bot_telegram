/*
• Base Ori Dilzz Official
Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Bikinan Sendiri, Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Dilzz [ Develover Sc ]  
- Dilzz [ Support ]
- Dilzz [Recode]
- Pengguna Bot Yang Selalu Support

• Recode By ( Dilzz  )
*/

const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const settings = require('./settings')
const botToken = settings.token;
const owner = settings.adminId;
const adminfile = 'adminID.json';
const premiumUsersFile = 'premiumUsers.json';
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premium Users file:', error);
}
const bot = new TelegramBot(botToken, { polling: true });
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading admin Users file:', error);
}
function getRuntime(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} 𝗝𝗮𝗺 ${minutes} 𝗠𝗲𝗻𝗶𝘁 ${seconds} 𝗗𝗲𝘁𝗶𝗸`;
}
const nama = '𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹';
const author = '𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹';
// Informasi waktu mulai bot
const startTime = Date.now();
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const startTime = Date.now();
    const menuText = `
𝗛𝗔𝗜 @${sender} 𝗦𝗔𝗬𝗔 𝗔𝗗𝗔𝗟𝗔𝗛 ${nama}

┌ – 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𝗕𝗢𝗧 –
  🤖 𝗡𝗔𝗠𝗘 𝗕𝗢𝗧: ${nama}
  👤 𝗢𝗪𝗡𝗘𝗥: ${author}
  ⏲️ 𝗥𝗨𝗡 𝗧𝗜𝗠𝗘: ${getRuntime(startTime)}
└ 
┌ – 𝗖𝗘𝗞 𝗜𝗗 𝗧𝗘𝗟𝗘 –
│ /cekid
└ 

┌ – 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗠𝗘𝗡𝗨 –
│ /panel
│ /ramlist
└ 
┌ – 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 –
│ /addowner
│ /delowner
│ /addprem
│ /delprem
│ /listsrv
│ /delsrv
│ /createadmin
│ /listadmin
└ 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 –`;
// Event listener for button 'Start'
bot.on('callback_query', (callbackQuery) => {
    if (callbackQuery.data === 'start') {
        const chatId = callbackQuery.message.chat.id;
        const startTime = Date.now();

        const menuText = `
𝗛𝗔𝗜 @${pushname} 𝗦𝗔𝗬𝗔 𝗔𝗗𝗔𝗟𝗔𝗛 ${nama}

┌ – 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𝗕𝗢𝗧 –
  🤖 𝗡𝗔𝗠𝗘 𝗕𝗢𝗧: ${nama}
  👤 𝗢𝗪𝗡𝗘𝗥: ${author}
  ⏲️ 𝗥𝗨𝗡 𝗧𝗜𝗠𝗘: ${getRuntime(startTime)}
└ 

┌ – 𝗖𝗘𝗞 𝗜𝗗 𝗧𝗘𝗟𝗘 –
│ /cekid
└ 

┌ – 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗠𝗘𝗡𝗨 –
│ /ᴘᴀɴᴇʟ
│ /ʀᴀᴍʟɪsᴛ
└ 
┌ – 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 –
│ /addowner
│ /delowner
│ /addprem
│ /delprem
│ /listsrv
│ /delsrv
│ /createadmin
│ /listadmin
└ 𝗗𝗶𝗹𝘇𝘇 𝗼𝗳𝗳𝗶𝗰𝗶𝗮𝗹 –`;
 const message = menuText;
 const keyboard = {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '💾 𝗥𝗔𝗠 𝗟𝗜𝗦𝗧', callback_data: 'ramlist' }],

                ]
            }
        };
        bot.answerCallbackQuery(callbackQuery.id);
        bot.editMessageText(message, {
            chat_id: chatId,
            message_id: callbackQuery.message.message_id,
            reply_markup: keyboard,
            parse_mode: 'Markdown'
        });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// cekid
bot.onText(/\/cekid/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const id = msg.from.id;
    const owner = '7454054827'; // Ganti dengan ID pemilik bot 
    const text12 = `𝗛𝗔𝗜 @${sender} 👋
    
👤 𝗗𝗔𝗥𝗜 ${id}
  └🙋🏽 𝗞𝗔𝗠𝗨
  
 𝗜𝗗 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠 𝗔𝗡𝗗𝗔 𝗔𝗗𝗔𝗟𝗔𝗛 : ${id}
 𝗡𝗔𝗠𝗔 𝗔𝗡𝗗𝗔 𝗔𝗗𝗔𝗟𝗔𝗛 : @${sender}
 
 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 : 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹', url: 'https://t.me/-' }, { text: '-', url: 'https://t.me/-' }],
                [{ text: '-', url: 'https://t.me/-' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// ramlist
bot.onText(/\/ramlist/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '7454054827'; // Ganti dengan ID pemilik bot 
    const text12 = `*𝗛𝗔𝗜 @${sender} 👋*
    
– 𝗟𝗜𝗦𝗧 𝗥𝗔𝗠 𝗗𝗔𝗡 𝗖𝗣𝗨 –
• 𝟭𝗚𝗕 - 𝟮𝟱% 𝗖𝗣𝗨
• 𝟮𝗚𝗕 - 𝟱𝟬% 𝗖𝗣𝗨
• 𝟯𝗚𝗕 - 𝟳𝟱% 𝗖𝗣𝗨
• 𝟰𝗚𝗕 - 𝟭𝟬𝟬% 𝗖𝗣𝗨
• 𝟱𝗚𝗕 - 𝟭𝟮𝟱% 𝗖𝗣𝗨
• 𝟲𝗚𝗕 - 𝟭𝟱𝟬% 𝗖𝗣𝗨
• 𝟳𝗚𝗕 - 𝟭𝟳𝟱% 𝗖𝗣𝗨
• 𝟴𝗚𝗡 - 𝟮𝟬𝟬% 𝗖𝗣𝗨
• 𝟵𝗚𝗕 - 𝟮𝟮𝟱% 𝗖𝗣𝗨
• 𝟭𝟬𝗚𝗕 - 𝟮𝟱𝟬% 𝗖𝗣𝗨
• 𝗨𝗡𝗟𝗜 - 𝗨𝗡𝗟𝗜% 𝗖𝗣𝗨

– 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 –
`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ 𝗕𝘂𝘆 𝗣𝗮𝗻𝗲𝗹', url: 'https://t.me/savedilz' }, { text: '👤 𝗕𝘂𝘆 𝗔𝗱𝗺𝗶𝗻', url: 'https://t.me/savedilz/𝗯𝘂𝘆 𝗮𝗱𝗺𝗶𝗻 & 𝗽𝘁 𝗽𝗮𝗻𝗲𝗹' }],
                [{ text: '🇲🇨 𝗕𝘂𝘆 𝗩𝗽𝘀', url: 'https://t.me/savedilz/𝗯𝘂𝘆 𝘃𝗽𝘀' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// ramlist2
const message = menuText;
const keyboard = {
  reply_markup: {
  inline_keyboard: [
  [{ text: '💾 𝗥𝗔𝗠 𝗟𝗜𝗦𝗧', callback_data: 'ramlist' }],

            ]
        }
    }; 
    bot.sendMessage(chatId, message, keyboard);
});
bot.on('callback_query', (callbackQuery) => {
  if (callbackQuery.data === 'ramlist') {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage = "– 𝗟𝗜𝗦𝗧 𝗥𝗔𝗠 𝗗𝗔𝗡 𝗖𝗣𝗨 –\n• 𝟭𝗚𝗕 - 𝟮𝟱% 𝗖𝗣𝗨\n• 𝟮𝗚𝗕 - 𝟱𝟬% 𝗖𝗣𝗨\n• 𝟯𝗚𝗕 - 𝟳𝟱% 𝗖𝗣𝗨\n• 𝟰𝗚𝗕 - 𝟭𝟬𝟬% 𝗖𝗣𝗨\n• 𝟱𝗚𝗕 - 𝟭𝟮𝟱% 𝗖𝗣𝗨\n• 𝟲𝗚𝗕 𝟭𝟱𝟬% 𝗖𝗣𝗨\n• 𝟳𝗚𝗕 - 𝟭𝟳𝟱% 𝗖𝗣𝗨\n• 𝟴𝗚𝗕 - 𝟮𝟬𝟬% 𝗖𝗣𝗨\n•  𝟵𝗚𝗡 𝟮𝟮𝟱% 𝗖𝗣𝗨\n• 𝟭𝟬𝗚𝗡 𝟮𝟱𝟬% 𝗖𝗣𝗨\n• 𝗨𝗡𝗟𝗜 - 𝗨𝗡𝗟𝗜% 𝗖𝗣𝗨\n – 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 –";
    bot.editMessageText(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: '𝗞𝗘𝗠𝗕𝗔𝗟𝗜 𝗞𝗘 𝗠𝗘𝗡𝗨 𝗦𝗧𝗔𝗥𝗧', callback_data: 'start' }]
        ]
      }
    });
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗦𝗜𝗠𝗣𝗔𝗡 𝗗𝗔𝗟𝗔𝗠 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗣𝗥𝗘𝗠𝗜𝗨𝗠.`);
        } else {
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔 𝗗𝗜 𝗗𝗔𝗟𝗔𝗠 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗣𝗥𝗘𝗠𝗜𝗨𝗠.`);
        }
    } else {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟𝗗𝗜 𝗛𝗔𝗣𝗨𝗦 𝗗𝗔𝗥𝗜 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗣𝗥𝗘𝗠𝗜𝗨𝗠.`);
        } else {
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠.`);
        }
    } else {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗦𝗜𝗠𝗣𝗔𝗡 𝗗𝗔𝗟𝗔𝗠 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗢𝗪𝗡𝗘𝗥.`);
        } else {
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔 𝗗𝗜 𝗗𝗔𝗟𝗔𝗠 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗢𝗪𝗡𝗘𝗥.`);
        }
    } else {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜 𝗛𝗔𝗣𝗨𝗦 𝗗𝗔𝗥𝗜 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗢𝗪𝗡𝗘𝗥.`);
        } else {
            bot.sendMessage(chatId, `𝗜𝗗 ${userId} 𝗕𝗨𝗞𝗔𝗡 𝗢𝗪𝗡𝗘𝗥.`);
        }
    } else {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 🤓.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// panel
bot.onText(/\/panel/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '7454054827'; // Ganti dengan ID pemilik bot 
    const text12 = `*𝗛𝗔𝗜 @${sender} 👋*
    𝗨𝗡𝗧𝗨𝗞 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗣𝗔𝗡𝗘𝗟 𝗞𝗘𝗧𝗜𝗞 /ʀᴀᴍ ᴜsᴇʀɴᴀᴍᴇ,ɪᴅᴛᴇʟᴇ
𝗖𝗢𝗡𝗧𝗢𝗛 : /1gb Dilzz,7454054827
𝗨𝗡𝗧𝗨𝗞 𝗠𝗘𝗟𝗜𝗛𝗔𝗧 𝗥𝗔𝗠 𝗟𝗜𝗦𝗧 𝗞𝗘𝗧𝗜𝗞 /ʀᴀᴍʟɪsᴛ
`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ 𝗕𝘂𝘆 𝗣𝗮𝗻𝗲𝗹', url: 'https://t.me/savedilz/buy_panel' }, { text: '👤 𝗕𝘂𝘆 𝗔𝗱𝗺𝗶𝗻', url: 'https://t.me/savedilz/𝗯𝘂𝘆 𝗮𝗱𝗺𝗶𝗻 & 𝗽𝘁 𝗽𝗮𝗻𝗲𝗹' }],
                [{ text: '🇲🇨 𝗕𝘂𝘆 𝗩𝗽𝘀', url: 'https://t.me/savedilz/𝗯𝘂𝘆 𝘃𝗽𝘀' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 1gb
bot.onText(/\/1gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗞𝗔𝗦𝗜𝗛𝗔𝗡, 𝗕𝗲𝗹𝗶 𝗞𝗲 𝗢𝘄𝗻𝗲𝗿 𝗔𝗷𝗮', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /Panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '1GB';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '1024';
  const cpu = '25';
  const disk = '1024';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}223`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗘𝗠𝗔𝗜𝗟 𝗧𝗘𝗥𝗦𝗘𝗕𝗨𝗧 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 2gb
bot.onText(/\/2gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗢𝗪𝗡𝗘𝗥', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '2gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '2048';
  const cpu = '50';
  const disk = '2048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}221`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 3gb
bot.onText(/\/3gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id)); 
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '3gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '3072';
  const cpu = '75';
  const disk = '6144';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}77qr`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 4gb
bot.onText(/\/4gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '4gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '4048';
  const cpu = '100';
  const disk = '4048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/np  m uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}1112`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡..');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 5gb
bot.onText(/\/5gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '5gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '5048';
  const cpu = '125';
  const disk = '5048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}pp1q`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗞: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 6gb
bot.onText(/\/6gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟ʟ', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '6gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '6048';
  const cpu = '150';
  const disk = '6048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}w3e1`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡..');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 7gb
bot.onText(/\/7gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '7gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '7048';
  const cpu = '175';
  const disk = '7048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}sdzj121`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗠 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 8gb
bot.onText(/\/8gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '8gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '8048';
  const cpu = '200';
  const disk = '8048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}zhks1`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 9gb
bot.onText(/\/9gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '9gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '9048';
  const cpu = '225';
  const disk = '9048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}871`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗠 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 10gb
bot.onText(/\/10gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '10gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '10000';
  const cpu = '250';
  const disk = '10000';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const password = `${username}881`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗡𝗔𝗠𝗔: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗:  ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}

🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});

// unli
bot.onText(/\/unli (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, '𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗨𝗦𝗘𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠, 𝗕𝗘𝗟𝗜 𝗔𝗧𝗔𝗨 𝗠𝗜𝗡𝗧𝗔 𝗔𝗗𝗗𝗣𝗥𝗘𝗠 𝗞𝗘 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Owner', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, '𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗔𝗟𝗔𝗛 𝗞𝗘𝗧𝗜𝗞 /panel');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + 'unli';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '0';
  const cpu = '0';
  const disk = '0';
  const email = `${username}panel@hax.id`;
  const akunlo = settings.pp;
  const startup_cmd = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = `${username}2322`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, '𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 𝗦𝗨𝗗𝗔𝗛 𝗔𝗗𝗔, 𝗚𝗔𝗡𝗧𝗜 𝗗𝗘𝗡𝗚𝗔𝗡 𝗬𝗔𝗡𝗚 𝗟𝗔𝗜𝗡.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: startup_cmd,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔
𝗨𝗦𝗘𝗥: ${username}
𝗘𝗠𝗔𝗜𝗟: ${email}
𝗜𝗗: ${user.id}
𝗥𝗔𝗠: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
𝗗𝗜𝗦𝗞: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
𝗖𝗣𝗨: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `📦𝗣𝗔𝗞𝗘𝗧 𝗨𝗡𝗧𝗨𝗞 @${u}


🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${user.username}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password} 
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɢᴀɴᴛɪ ᴘᴀssᴡᴏʀᴅ 🥶
==============================`
        });
      bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗗𝗜𝗞𝗜𝗥𝗜𝗠 𝗞𝗘 𝗜𝗗 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗧𝗘𝗥𝗔.');
    }
  } else {
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @savedilz.');
  }
});
//batas
fs.readFile('adminID.json', (err, data) => {
  if (err) {
    console.error(err);
  } else {
    adminID = JSON.parse(data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// createadmin
bot.onText(/\/createadmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) {
    bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹', url: 'https://t.me/savedilz' }
          ]
        ]
      }
    });
    return;
  }
  const commandParams = match[1].split(',');
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(chatId, '𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛!');
    return;
  }
  const password = panelName + "11212";
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: `${panelName}@bokekactyl.admin`,
        username: panelName,
        first_name: panelName,
        last_name: "ADMIN",
        language: "en",
        root_admin: true,
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
𝗧𝗬𝗣𝗘: 𝘂𝘀𝗲𝗿
➟ 𝗜𝗗: ${user.id}
➟ 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: ${user.username}
➟ 𝗘𝗠𝗔𝗜𝗟: ${user.email}
➟ 𝗡𝗔𝗠𝗔: ${user.first_name} ${user.last_name}
➟ 𝗕𝗔𝗛𝗔𝗦𝗔 : ${user.language}
➟ 𝗔𝗗𝗠𝗜𝗡: ${user.root_admin}
➟ 𝗗𝗜 𝗕𝗨𝗔𝗧 : ${user.created_at}
➟ 𝗟𝗢𝗚𝗜𝗡: ${domain}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(telegramId, `
📦 𝗣𝗔𝗞𝗘𝗧 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟

𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝗔𝗡𝗗𝗔 ⤵️
🚩 𝗟𝗢𝗚𝗜𝗡 : ${domain}
🚩 𝗘𝗠𝗔𝗜𝗟 : ${user.email}
🚩 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : ${panelName}
🚩 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 : ${password}
==============================
➡️ 𝗡𝗢𝗧𝗘 : 

• 𝗝𝗔𝗡𝗚𝗔𝗡 𝗕𝗨𝗞𝗔/𝗥𝗨𝗦𝗨𝗛/𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗗𝗜 𝗦𝗘𝗥𝗩𝗘𝗥 𝗢𝗥𝗔𝗡𝗚 𝗟𝗔𝗜𝗡
• 𝗝𝗔𝗡𝗚𝗔𝗡 𝗕𝗨𝗞𝗔/𝗥𝗨𝗦𝗨𝗛/𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗗𝗜 𝗦𝗘𝗥𝗩𝗘𝗥 𝗔𝗗𝗠𝗜𝗡
• 𝗝𝗔𝗡𝗚𝗔𝗡 𝗘𝗗𝗜𝗧 𝗕𝗔𝗚𝗜𝗔𝗠 𝗖𝗢𝗡𝗧𝗥𝗢𝗟 𝗔𝗗𝗠𝗜𝗡/𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡/𝗡𝗢𝗗𝗘𝗦/𝗘𝗚𝗚/𝗡𝗘𝗦𝗧
• 𝗝𝗔𝗡𝗚𝗔𝗡 𝗔𝗞𝗧𝗜𝗙𝗞𝗔𝗡 𝗔𝟮𝗙
• 𝗦𝗘𝗥𝗩𝗘𝗥 𝗧𝗜𝗗𝗔𝗞 𝗗𝗜𝗚𝗨𝗡𝗔𝗞𝗔𝗡 𝗨𝗡𝗧𝗨𝗞 𝗦𝗘𝗟𝗔𝗜𝗡 𝗕𝗢𝗧 𝗥𝗜𝗡𝗚𝗔𝗡
• 𝗗𝗜𝗟𝗔𝗥𝗔𝗡𝗚 𝗞𝗘𝗥𝗔𝗦 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗔𝗞𝗨𝗡 𝗔𝗗𝗠𝗜𝗡 𝗞𝗘𝗖𝗨𝗔𝗟𝗜 𝗔𝗡𝗗𝗔 𝗢𝗪𝗠/𝗣𝗧 𝗗𝗔𝗥𝗜 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟

𝗟𝗔𝗡𝗚𝗚𝗔𝗥? 𝗕𝗟𝗔𝗖𝗞𝗟𝗜𝗦𝗧 𝗦𝗘𝗥𝗩𝗘𝗥
==============================
ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴜʙᴀʜ ᴘᴀssᴡᴏʀᴅ 🥶
==============================
    `);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, '𝗔𝗗𝗔 𝗘𝗥𝗥𝗢𝗥 𝗗𝗜 𝗕𝗔𝗚𝗜𝗔𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗕𝗔𝗡𝗚 @aavedilz.');
  }
});
fs.readFile(adminfile, (err, data) => {
  if (err) {
    console.error(err);
  } else {
    adminIDs = JSON.parse(data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listsrv
bot.onText(/\/listsrv/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;   
// Check if the user is the Owner
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
    if (!isAdmin) {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'revanstr', url: 'https://t.me/savedilz' }
                    ]
                ]
            }
        });
        return;
    }
    let page = 1; // Mengubah penggunaan args[0] yang tidak didefinisikan sebelumnya
    try {
        let f = await fetch(`${domain}/api/application/servers?page=${page}`, { // Menggunakan backticks untuk string literal
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let servers = res.data;
        let messageText = "𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗟𝗜𝗦𝗧 𝗦𝗘𝗥𝗩𝗘𝗥:\n\n";
        for (let server of servers) {
            let s = server.attributes;

            let f3 = await fetch(`${domain}/api/client/servers/${s.uuid.split('-')[0]}/resources`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${pltc}`
                }
            });
            let data = await f3.json();
            let status = data.attributes ? data.attributes.current_state : s.status;

            messageText += `𝗜𝗗 𝗦𝗘𝗥𝗩𝗘𝗥: ${s.id}\n`;
            messageText += `𝗡𝗔𝗠𝗔 𝗦𝗘𝗥𝗩𝗘𝗥: ${s.name}\n`;
            messageText += `𝗦𝗧𝗔𝗧𝗨𝗦: ${status}\n\n`;
        }

        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, '𝗧𝗘𝗥𝗝𝗔𝗗𝗜 𝗞𝗘𝗦𝗔𝗟𝗔𝗛𝗔𝗡 𝗧𝗜𝗗𝗔𝗞 𝗧𝗘𝗥𝗗𝗨𝗚𝗔.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//delsrv
bot.onText(/\/delsrv(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const srv = match[1].trim();

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Owner', url: 'https://t.me/savedilz' }
                    ]
                ]
            }
        });
        return;
    }

    if (!srv) {
        bot.sendMessage(chatId, '𝗙𝗢𝗥𝗠𝗔𝗧 𝗦𝗔𝗟𝗔𝗛, 𝗙𝗢𝗥𝗠𝗔𝗧: /delsrv id');
        return;
    }

    try {
        let f = await fetch(`${domain}/api/application/servers/${srv}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, '𝗧𝗜𝗗𝗔𝗞 𝗔𝗗𝗔 𝗦𝗘𝗥𝗩𝗘𝗥 𝗜𝗗 𝗧𝗘𝗥𝗦𝗘𝗕𝗨𝗧');
        } else {
            bot.sendMessage(chatId, '𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗠𝗘𝗡𝗚𝗛𝗔𝗣𝗨𝗦 𝗦𝗘𝗥𝗩𝗘𝗥 𝗧𝗘𝗥𝗦𝗘𝗕𝗨𝗧');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, '𝗧𝗘𝗥𝗝𝗔𝗗𝗜 𝗞𝗘𝗦𝗔𝗟𝗔𝗛𝗔𝗡 𝗧𝗜𝗗𝗔𝗞 𝗧𝗘𝗥𝗗𝗨𝗚𝗔.');
    }
});
// listadmin
bot.onText(/\/listadmin/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, '𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿, 𝗗𝗶𝗹𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹🤓', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Owner', url: 'https://t.me/savedilz' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗟𝗜𝗦𝗧 𝗔𝗗𝗠𝗜𝗝 :\n\n";
        for (let user of users) {
            let u = user.attributes;
            if (u.root_admin) {
                messageText += `🆔 𝗜𝗗: ${u.id} - 🌟 𝗦𝗧𝗔𝗧𝗨𝗦: ${u.attributes?.user?.server_limit === null ? '𝗜𝗻𝗮𝗰𝘁𝗶𝘃𝗲' : '𝗔𝗰𝘁𝗶𝘃𝗲'}\n`;
                messageText += `${u.username}\n`;
                messageText += `${u.first_name} ${u.last_name}\n\n`;
                messageText += '𝗕𝗬 𝗗𝗜𝗟𝗭𝗭 𝗢𝗙𝗙𝗜𝗖𝗜𝗔𝗟';
            }
        }
        messageText += `𝗣𝗔𝗚𝗘: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `𝗧𝗢𝗧𝗔𝗟 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟: ${res.meta.pagination.count}`;
        const keyboard = [
            [
                { text: '𝗞𝗘𝗠𝗕𝗔𝗟𝗜', callback_data: JSON.stringify({ action: 'back', page: parseInt(res.meta.pagination.current_page) - 1 }) },
                { text: '𝗟𝗔𝗡𝗝𝗨𝗧', callback_data: JSON.stringify({ action: 'next', page: parseInt(res.meta.pagination.current_page) + 1 }) }
            ]
        ];
        bot.sendMessage(chatId, messageText, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// batas akhir
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, '𝗧𝗘𝗥𝗝𝗔𝗗𝗜 𝗞𝗘𝗦𝗔𝗟𝗔𝗛𝗔𝗡 𝗧𝗜𝗗𝗔𝗞 𝗧𝗘𝗥𝗗𝗨𝗚𝗔.');
    }
});