/*
• Base Ori Dilzz Official
Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Bikinan Sendiri, Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Dilzz [ Develover Sc ]  
- Dilzz [ Support ]
- Dilzz [Recode]
- Pengguna Bot Yang Selalu Support

• Recode By ( Dilzz  )
*/

require("/start")
require("/menu")
